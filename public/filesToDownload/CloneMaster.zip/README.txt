10

Please write your major version of Windows in first line so the menu will open properly.